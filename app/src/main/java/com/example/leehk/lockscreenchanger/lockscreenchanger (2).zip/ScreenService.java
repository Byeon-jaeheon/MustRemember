package com.example.leehk.lockscreenchanger;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.inputmethodservice.Keyboard;
import android.os.Handler;
import android.os.IBinder;
import android.widget.Toast;

/**
 * Created by leehk on 2016-07-12.
 */
public class ScreenService extends Service {

    private ScreenReceiver mReceiver = null;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        mReceiver = new ScreenReceiver();
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mReceiver, filter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId){
        super.onStartCommand(intent, flags, startId);
/*
        Notification notification = new Notification(R.drawable.ic_launcher, "서비스 실행됨", System.currentTimeMillis());
*/
        Notification.Builder builder = new Notification.Builder(getApplicationContext()).setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("lockscreen changer")
                .setContentText("잠금화면 실행중")
                .setContentIntent(null);
       Notification notification = builder.getNotification();
        startForeground(1, notification);
        if(intent != null){
            if(intent.getAction()==null){
                if(mReceiver==null){
                    mReceiver = new ScreenReceiver();
                    IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
                    registerReceiver(mReceiver, filter);
                }
            }
        }
        final Handler dK = new Handler();
        dK.post(new Runnable() {
            @Override

            public void run() {
                KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);

                KeyguardManager.KeyguardLock x = km.newKeyguardLock(getApplicationContext().KEYGUARD_SERVICE);
                x.disableKeyguard();
                dK.postDelayed(this, 500);
            }
        });

        return START_REDELIVER_INTENT;
    }

    @Override
    public void onDestroy(){
        super.onDestroy();

        if(mReceiver != null){
            unregisterReceiver(mReceiver);
        }
    }
}
